export default function EquipmentCard({ equipment }) {
  return (
    <div style={{ border: '1px solid #ddd', borderRadius: '10px', padding: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
      <img
        src={equipment.image}
        alt={equipment.name}
        style={{ width: '100%', height: '180px', objectFit: 'cover', borderRadius: '8px' }}
      />
      <h3>{equipment.name}</h3>
      <p>{equipment.city}</p>
      <p><strong>₹{equipment.dailyRate.toLocaleString()}/day</strong></p>
      <button style={{ background: '#f4b400', color: 'white', border: 'none', padding: '10px 16px', borderRadius: '6px' }}>
        Book Now
      </button>
    </div>
  );
}
