import EquipmentCard from './components/EquipmentCard.jsx';

const equipment = [
  { id: 1, name: 'JCB Backhoe Loader', city: 'Hyderabad', dailyRate: 8500, image: 'https://images.unsplash.com/photo-1599707254554-027aeb4deacd?auto=format&fit=crop&w=800&q=80' },
  { id: 2, name: 'Hydraulic Excavator', city: 'Vijayawada', dailyRate: 12000, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80' },
  { id: 3, name: 'Crawler Crane', city: 'Visakhapatnam', dailyRate: 25000, image: 'https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&w=800&q=80' }
];

export default function App() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      <h1>ProClainer – Heavy Equipment Rental Marketplace</h1>
      <p>Porter-like marketplace for JCBs, excavators, and cranes.</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
        {equipment.map(item => <EquipmentCard key={item.id} equipment={item} />)}
      </div>
    </div>
  );
}
