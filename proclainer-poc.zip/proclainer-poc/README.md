
# ProClainer POC

A React JSX proof of concept for a Porter-like marketplace for renting JCBs, excavators, and cranes.

## Run Locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.
